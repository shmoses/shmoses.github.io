#!/bin/bash

git submodule init
git submodule update --remote --recursive
