from tasks import TaskManager

tm = TaskManager()
tm.do_recrawl()
